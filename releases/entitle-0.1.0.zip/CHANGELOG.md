# Change Log #
All notable changes to this project will be documented in this file. This
project adheres to [Semantic Versioning](http://semver.org/).

## [Unreleased] ##
### Added ###
### Changed ###
### Fixed ###

## 0.1.0 - 2017-02-11 ##
### Added ###
- Implement `craft()->entitle->capitalize` service method.
- Implement `craft.entitle.capitalize` template variable.
- Implement `entitle` Twig filter.

[Unreleased]: https://github.com/experience/entitle.craftplugin/compare/v0.1.0...HEAD
